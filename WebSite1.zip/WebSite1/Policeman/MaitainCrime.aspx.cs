﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Policeman_MaitainCrime : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    String id = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        bool stop = false;
        try
        {
            con.Open();
            String sql = "select * from CRIME";
            SqlCommand com = new SqlCommand(sql, con);
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read() && !stop)
            {
                if (reader["CRIME_TYPE"].ToString() == "")
                {
                    stop = true;
                    id = reader["USER_ID"].ToString();
                    Category.Text = reader["VICTIM_CATEGORY"].ToString();
                    description.Text = reader["DESCRIPTION"].ToString();
                }
            }
            reader.Close();

            String usersql = "select FIRST_NAME, SURNAME from [USER] where USER_ID = '" + id + "'";
            SqlCommand usercom = new SqlCommand(usersql, con);
            SqlDataReader userreader = usercom.ExecuteReader();
            while (userreader.Read())
            {
                String fname = userreader["FIRST_NAME"].ToString();
                String sname = userreader["SURNAME"].ToString();
                uname.Text = fname + " " + sname;
            }
            userreader.Close();

            String poposql = "select FIRST_NAME, SURNAME from POLICEMAN where POLICE_ID = '" + Session["PopoID"].ToString() + "'";
            SqlCommand popocom = new SqlCommand(poposql, con);
            SqlDataReader poporeader = popocom.ExecuteReader();
            while (poporeader.Read())
                policeman.Text = poporeader["FIRST_NAME"].ToString() + " " + poporeader["SURNAME"].ToString();
            poporeader.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    protected void save(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            String sqlQuery = "update Crime set CRIME_TYPE = @type, SQUAD_CAR = @car where CRIME_ID = @crimeID";
            SqlCommand comTime = new SqlCommand(sqlQuery, con);
            comTime.Parameters.AddWithValue("@type", Request.Form["testSelect"]); //Not working
            if (squad.Checked)
                comTime.Parameters.AddWithValue("@car", 1);
            else
                comTime.Parameters.AddWithValue("@car", 0);
            comTime.Parameters.AddWithValue("@crimeID", id);
            comTime.ExecuteNonQuery();
            Response.Write("UPDATE works");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            //Response.Redirect("~/Policeman/PopoMain.aspx");
        }
    }
}