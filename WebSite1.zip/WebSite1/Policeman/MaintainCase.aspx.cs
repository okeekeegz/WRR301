﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Policeman_MaintainCase : System.Web.UI.Page
{
    //ArrayList list = new ArrayList();
    //String ID = "";

    //protected void btnEvaluate_Click(object sender, EventArgs e)
    //{
    //    Session["CaseNo"] = ID;
    //    Response.Redirect("EvaluateCase.aspx");
    //}

    

    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void tblCase_Init(object sender, EventArgs e)
    {
        ArrayList list = new ArrayList();
        //String ID = "";

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        String myCount = "select count(*) from [CASES]";
        SqlCommand com = new SqlCommand(myCount, con);
        int user = 0;
        user = Convert.ToInt32(com.ExecuteScalar().ToString());
        //con.Close();

        int count = 0;

        if (user > 0)
            count = 1;

        TableHeaderRow h1 = new TableHeaderRow();
        TableHeaderCell c1 = new TableHeaderCell();
        TableHeaderCell c2 = new TableHeaderCell();
        TableHeaderCell c3 = new TableHeaderCell();

        c1.Text = "Case ID";
        c2.Text = "Description";
        c3.Text = " ";

        h1.Cells.Add(c1);
        h1.Cells.Add(c2);
        h1.Cells.Add(c3);

        tblCase.Rows.Add(h1);

        while (count <= user)
        {
            String ID = "select CASE_NO from [CASES] where CASE_NO = 'C" + count + "'";
            String Descr = "select CASE_DESCRIPTION from [CASES] where CASE_NO = 'C" + count + "'";
            String evaluated = "select SUMMARY from [CASES] where CASE_NO = 'C" + count + "'";
            //String fname = "select FIRST_NAME from [POLICEMAN] where USER_NAME = '" + Session["New"].ToString() + "'";

            SqlCommand com1 = new SqlCommand(ID, con);
            SqlCommand com2 = new SqlCommand(Descr, con);
            SqlCommand com3 = new SqlCommand(evaluated, con);

            String realfname = com1.ExecuteScalar().ToString().Replace(" ", "");
            String realsname = com2.ExecuteScalar().ToString();
            String eval = com3.ExecuteScalar().ToString();
            if (eval == "")
            {
                TableRow row = new TableRow();
                TableCell cell1 = new TableCell();
                TableCell cell2 = new TableCell();
                TableCell cell3 = new TableCell();

                cell1.Text = realfname;
                cell2.Text = realsname;
                Button btn = new Button();
                btn.Text = "Evaluate";
                btn.Attributes.Add("class", ".btn");
                ID = realfname;
                //btn.Click += new EventHandler(btnEvaluate_Click);
                btn.Click += (s, ev) => { Session["CaseNo"] = ID; Response.Redirect("EvaluateCase.aspx"); };
                cell3.Controls.Add(btn);

                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                tblCase.Rows.Add(row);
            }
            count++;
        }





        con.Close();
    }
}