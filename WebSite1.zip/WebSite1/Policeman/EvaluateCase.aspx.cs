﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Policeman_EvaluateCase : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    String userID = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            String sqlCase = "select * from CASES where CASE_NO = '" + Session["CaseNo"].ToString() + "'";
            SqlCommand com = new SqlCommand(sqlCase, con);
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                CaseNo.Text = Session["CaseNo"].ToString();
                crType.Text = reader["CRIME_TYPE"].ToString();
                involved.Text = reader["PERSON_INVOLVED"].ToString();
                CaseDescr.Text = reader["CASE_DESCRIPTION"].ToString();
                userID = reader["USER_ID"].ToString();
                DateNow.Text = reader["DATE"].ToString();
            }
            con.Close();
            con.Open();
            String sqlUser = "select * from [USER] where USER_ID = '" + userID + "'";
            SqlCommand comUser = new SqlCommand(sqlUser, con);
            SqlDataReader readerUser = comUser.ExecuteReader();
            while (readerUser.Read())
            {
                firstName.Text = readerUser["FIRST_NAME"].ToString();
                SurName.Text = readerUser["SURNAME"].ToString();                
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();           
        }
    }

    protected void save(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            String sqlQuery = "update CASES set ACTIONS_TAKEN = @taken, SUMMARY = @sum where CASE_NO = @caseID";
            SqlCommand comTime = new SqlCommand(sqlQuery, con);
            comTime.Parameters.AddWithValue("@taken", ActionTaken.Text);
            comTime.Parameters.AddWithValue("@sum", Summary.Text);
            comTime.Parameters.AddWithValue("@caseID", Session["CaseNo"].ToString());
            comTime.ExecuteNonQuery();
            Response.Write("UPDATE works");

            String mySQL = "insert into CASE_DETAILS(CASE_NO, POLICE_ID) values (@no, @id)";
            SqlCommand comDetails = new SqlCommand(mySQL, con);
            comDetails.Parameters.AddWithValue("@no", Session["CaseNo"].ToString());
            comDetails.Parameters.AddWithValue("@id", Session["PopoID"].ToString());
            comDetails.ExecuteNonQuery();
            Response.Write("INSERT works");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            Response.Redirect("~/Policeman/PopoMain.aspx");
        }
    }
}