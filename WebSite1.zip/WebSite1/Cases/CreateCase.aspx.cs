﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class Cases_CreateCase : System.Web.UI.Page
{
    ArrayList caseList = new ArrayList();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);

    string tm;
    string UI;
    string CI;
    String caseNum = "C1";
   
    protected void Page_Load(object sender, EventArgs e)
    {

        con.Open();
        String myCount = "select count(*) from [CASES]";
        SqlCommand com = new SqlCommand(myCount, con);
        int user = 0;
        user = Convert.ToInt32(com.ExecuteScalar().ToString());

        if (user > 0)
        {
            //caseNum = "C00" + (user + 1);
            //if (user >= 10)
            //{
            //    caseNum = "C0" + (user + 1);
            //    if (user >= 100)
            //    {
            //        caseNum = "C" + (user + 1);
            //    }
            //}
            caseNum = "C" + (user + 1);
        }

        CaseNo.Text = caseNum;

        Session["Date"] = DateTime.Now;

        String curdate = Convert.ToDateTime(Session["Date"].ToString()).Date.ToShortDateString();
        tm = Convert.ToDateTime(Session["Date"].ToString()).TimeOfDay.Duration().ToString();

        //con.Open();
        String fname = "select FIRST_NAME from [USER] where USER_NAME = '" + Session["New"].ToString() + "'";
        String sname = "select SURNAME from [USER] where USER_NAME = '" + Session["New"].ToString() + "'";
        String uID = "select USER_ID from [USER] where USER_NAME = '" + Session["New"].ToString() + "'";



        SqlCommand com1 = new SqlCommand(fname, con);
        SqlCommand com2 = new SqlCommand(sname, con);
        SqlCommand com3 = new SqlCommand(uID, con);


        String realfname = com1.ExecuteScalar().ToString().Replace(" ", "");
        String realsname = com2.ExecuteScalar().ToString().Replace(" ", "");
        UI = com3.ExecuteScalar().ToString().Replace(" ", "");


        firstName.Text = realfname;
        SurName.Text = realsname;
        DateNow.Text = curdate;

        con.Close();

        //string num = "0123456789";
        //int len = num.Length;
        //char cha = 'C';
        //string otp = string.Empty;
        //// number of charecters in case Num
        //int otpdigit = 4;
        //string finalCaseNo;
        //int getindex;
        //for (int i = 0; i < otpdigit; i++)
        //{
        //    do
        //    {
        //        getindex = new Random().Next(0, len);
        //        finalCaseNo = num.ToCharArray()[getindex].ToString();
        //    } while (otp.IndexOf(finalCaseNo) != -1);
        //    otp += finalCaseNo;
        //}
        //// int index = 0;
        //CaseNo.Text = cha + otp;

        //char c = 'C';
        //con.Open();


        /*  // bool duplicate = false;
          // getCaseNo();
           while(caseList.Count!=-1)
           {
               if (caseList[index].Equals(Cs))
               {                
                   duplicate = true;
                   return;
               }
           }
           if (!duplicate)
               CaseNo.Text = cha + otp;*/

        // Read data from the database and assign them to a label.
        

       /* try
        {
            con.Open();
            String sqlQuery = "insert into [CASES] (CASE_NO, CASE_DESCRIPTION,PERSORN_INVOLVE,DATE,TIME, USER_ID,CRIME_ID) values (@idnew, @descrip, @person, @date, @time,@userId,@crimeId)";
            SqlCommand com = new SqlCommand(sqlQuery, con);

            com.Parameters.AddWithValue("@idnew", CaseNo.Text);
            com.Parameters.AddWithValue("@descrip", Description.Text);
            com.Parameters.AddWithValue("@person", PerInvolve.Text);
            com.Parameters.AddWithValue("@date", DateNow.Text);
            com.Parameters.AddWithValue("@time", tm);
            com.Parameters.AddWithValue("@userId", UI);
            com.Parameters.AddWithValue("@crimeId",CI);

            com.ExecuteNonQuery();
            con.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);
        }*/

    }

    /*  private void getCaseNo()
      {
          SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);

          con.Open();
          String checkUser = "select count(*) from [USER] where USER_NAME = '" + Session["New"].ToString() + "'";
          SqlCommand com = new SqlCommand(checkUser, con);
          int user = Convert.ToInt32(com.ExecuteScalar().ToString());
          con.Close();

          if(user==1)
          {
              con.Open();
              String CaseNo = "select CASE_NO from [CASES], [USER] where CASES.USER_ID = USER.USER_ID";
              SqlCommand com1 = new SqlCommand(CaseNo, con);
              int Num = Convert.ToInt32(com1.ExecuteScalar().ToString());
              if (Num == null)
                  return;
              String realCaseNo = com1.ExecuteScalar().ToString().Replace(" ", "");
              caseList.Add(realCaseNo);
              con.Close();
          }*/

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            
            //con.Close();

            //int count = 0;
            con.Open();
            String sqlQuery = "insert into [CASES] (CASE_NO, CASE_DESCRIPTION,PERSON_INVOLVED,DATE,TIME, USER_ID,CRIME_TYPE) values (@idnew, @descrip, @person, @date, @time,@userId,@TYPE)";
            SqlCommand mycom = new SqlCommand(sqlQuery, con);

            mycom.Parameters.AddWithValue("@idnew", caseNum);
            mycom.Parameters.AddWithValue("@descrip", Description.Text);
            mycom.Parameters.AddWithValue("@person", PerInvolve.Text);
            mycom.Parameters.AddWithValue("@date", DateNow.Text);
            mycom.Parameters.AddWithValue("@time", tm);
            mycom.Parameters.AddWithValue("@userId", UI);
            mycom.Parameters.AddWithValue("@TYPE", c_Type.Text);


            mycom.ExecuteNonQuery();

            //if (user > 0)
            //{
                

                


            //    //Cases myCase = new Cases();
            //    //caseList.Add(myCase);
            //}
            //else
            //{

                //Session["Date"] = DateTime.Now;

                //String curdate = Convert.ToDateTime(Session["Date"].ToString()).Date.ToShortDateString();
                //tm = Convert.ToDateTime(Session["Date"].ToString()).TimeOfDay.Duration().ToString();

                //con.Open();
                //String fname = "select FIRST_NAME from [USER] where USER_NAME = '" + Session["New"].ToString() + "'";
                //String sname = "select SURNAME from [USER] where USER_NAME = '" + Session["New"].ToString() + "'";
                //String uID = "select USER_ID from [USER] where USER_NAME = '" + Session["New"].ToString() + "'";



                //SqlCommand com1 = new SqlCommand(fname, con);
                //SqlCommand com2 = new SqlCommand(sname, con);
                //SqlCommand com3 = new SqlCommand(uID, con);


                //String realfname = com1.ExecuteScalar().ToString().Replace(" ", "");
                //String realsname = com2.ExecuteScalar().ToString().Replace(" ", "");
                //UI = com3.ExecuteScalar().ToString().Replace(" ", "");


                //firstName.Text = realfname;
                //SurName.Text = realsname;
                //DateNow.Text = curdate;

                //String sqlQuery = "insert into [CASES] (CASE_NO, CASE_DESCRIPTION,PERSON_INVOLVED,DATE,TIME, USER_ID,CRIME_TYPE) values (@idnew, @descrip, @person, @date, @time,@userId,@TYPE)";
                //SqlCommand mycom = new SqlCommand(sqlQuery, con);

                //mycom.Parameters.AddWithValue("@idnew", "C1");
                //mycom.Parameters.AddWithValue("@descrip", Description.Text);
                //mycom.Parameters.AddWithValue("@person", PerInvolve.Text);
                //mycom.Parameters.AddWithValue("@date", DateNow.Text);
                //mycom.Parameters.AddWithValue("@time", tm);
                //mycom.Parameters.AddWithValue("@userId", UI);
                //mycom.Parameters.AddWithValue("@TYPE", c_Type.Text);


                //mycom.ExecuteNonQuery();
               // con.Close();
                //Console.WriteLine("Should save to the database!!!");
            


            con.Close();
            
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);
            con.Close();
        }
    }

    class Cases
    {
        String Case_No, Case_Description, Person_Involved, Date, Time, User_ID, Crime_Type, Actions_Taken, Summary;

        public Cases(String Case_No, String Case_Description, String Person_Involved, String Date, String Time, String User_ID, String Crime_Type, String Actions_Taken, String Summary)
        {
            this.Case_No = Case_No;
            this.Case_Description = Case_Description;
            this.Person_Involved = Person_Involved;
            this.Date = Date;
            this.Time = Time;
            this.User_ID = User_ID;
            this.Crime_Type = Crime_Type;
            this.Actions_Taken = Actions_Taken;
            this.Summary = Summary;
        }
    }
}


