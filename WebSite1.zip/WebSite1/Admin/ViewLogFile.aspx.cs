﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

public partial class Default3 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    StringBuilder table = new StringBuilder();

    string log_Num = "L1";

    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
        string LOG_policeID = "Select LOG_FILE.POLICE_ID FROM LOG_FILE,POLICEMAN WHERE LOG_FILE.POLICE_ID=POLICEMAN.POLICE_ID";
        string POLICEID = "Select POLICE_ID FROM [POLICEMAN]";
        string LOG_USERID = "Select LOG_FILE.USER_ID FROM [LOG_FILE]";
        string User_ID = "Select USER FROM [USER]";

        SqlCommand com1 = new SqlCommand(LOG_policeID, con);
        SqlCommand com2 = new SqlCommand(POLICEID, con);
        SqlCommand com3 = new SqlCommand(LOG_USERID, con);
        SqlCommand com4 = new SqlCommand(User_ID, con);

        String L_P_ID = com1.ExecuteScalar().ToString().Replace(" ", "");
        String p_ID = com2.ExecuteScalar().ToString().Replace(" ", "");
        String L_U_ID = com3.ExecuteScalar().ToString().Replace(" ", "");
        String U_ID = com4.ExecuteScalar().ToString().Replace(" ", "");

        string COUNTLOGS = "Select COUNT(*) FROM [LOG_FILE]";
        SqlCommand com = new SqlCommand(COUNTLOGS, con);
        int COUNT = Convert.ToInt32(com.ExecuteScalar().ToString());

        while (COUNT > 0)
        {
            string curCount =  "Select COUNT(*) FROM [LOG_FILE]";
            SqlCommand cmd = new SqlCommand(curCount, con);
            int myCou = Convert.ToInt32(cmd.ExecuteScalar().ToString());
            COUNT--;
            if (L_P_ID == p_ID)
            {
                TableHeaderRow h1 = new TableHeaderRow();
                TableHeaderCell c1 = new TableHeaderCell();
                TableHeaderCell c2 = new TableHeaderCell();
                TableHeaderCell c3 = new TableHeaderCell();

                c1.Text = "System User";
                c2.Text = "Date";
                c3.Text = "Time";

                h1.Cells.Add(c1);
                h1.Cells.Add(c2);
                h1.Cells.Add(c3);
                myTableView.Rows.Add(h1);

                String DTE = "select DATE from [LOG_FILE]";
                String TME = "select TIME from [LOG_FILE]";

                SqlCommand comD = new SqlCommand(DTE, con);
                SqlCommand comT = new SqlCommand(TME, con);

                String realDATE = comD.ExecuteScalar().ToString().Replace(" ", "");
                String realTIME = comT.ExecuteScalar().ToString().Replace(" ", "");

                TableRow row = new TableRow();
                TableCell cell1 = new TableCell();
                TableCell cell2 = new TableCell();
                TableCell cell3 = new TableCell();

                cell1.Text = "Policeman";
                cell2.Text = realDATE;
                cell3.Text = realTIME;

                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
            }
            else
            {
                TableHeaderRow h1 = new TableHeaderRow();
                TableHeaderCell c1 = new TableHeaderCell();
                TableHeaderCell c2 = new TableHeaderCell();
                TableHeaderCell c3 = new TableHeaderCell();

                c1.Text = "System User";
                c2.Text = "Date";
                c3.Text = "Time";

                h1.Cells.Add(c1);
                h1.Cells.Add(c2);
                h1.Cells.Add(c3);

                String DTE = "select DATE from [LOG_FILE]";
                String TME = "select TIME from [LOG_FILE]";

                SqlCommand comD = new SqlCommand(DTE, con);
                SqlCommand comT = new SqlCommand(TME, con);

                String realDATE = comD.ExecuteScalar().ToString().Replace(" ", "");
                String realTIME = comT.ExecuteScalar().ToString().Replace(" ", "");

                TableRow row = new TableRow();
                TableCell cell1 = new TableCell();
                TableCell cell2 = new TableCell();
                TableCell cell3 = new TableCell();

                cell1.Text = "User";
                cell2.Text = realDATE;
                cell3.Text = realTIME;

                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                myTableView.Rows.Add(row);
            }
        }
        
        con.Close();

        
    }
}