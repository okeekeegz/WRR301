﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Account_CreatePolice : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);


    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void CreatePolice_Click(object sender, EventArgs e)
    {
        try
        {

            Guid newG = Guid.NewGuid();

            con.Open();
            String sqlQuery = "insert into [POLICEMAN] (POLICE_ID, FIRST_NAME, SURNAME,RANK,USER_NAME, PASSWORD) values (@idnew, @fname, @sname, @rank, @uName,@pass)";
            SqlCommand com = new SqlCommand(sqlQuery, con);

            com.Parameters.AddWithValue("@idnew", newG.ToString());
            com.Parameters.AddWithValue("@fname", FirstName.Text);
            com.Parameters.AddWithValue("@sname", Surname.Text);
            com.Parameters.AddWithValue("@rank", Rank.Text);
            com.Parameters.AddWithValue("@uName", UserName.Text);
            com.Parameters.AddWithValue("@pass", Password.Text);

            com.ExecuteNonQuery();
            con.Close();
            Response.Redirect("Login.aspx");
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);
        }

    }
}