﻿using Microsoft.AspNet.Identity;
using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web.UI;
using WebSite1;

public partial class Account_Register : Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    //SqlCommand cmd = new SqlCommand();


    //SqlConnection newCon = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);

    String gender = " ";

    protected void CreateUser_Click(object sender, EventArgs e)
    {
        try
        {

            Guid newG = Guid.NewGuid();

            con.Open();
            String sqlQuery = "insert into [USER] (USER_ID, FIRST_NAME, SURNAME, ID_NO, GENDER, AGE, RACE, USER_NAME, PASSWORD) values (@idnew, @fname, @sname, @id, @gend, @agee, @races, @uname, @pass)";
            //String sql = "INSERT INTO [USER] VALUES('" + FirstName.Text + "', '" + Surname.Text + "', '" + ID.Text + "', '" + Gender.Text + "', '" + Age.Text + "', '" + Race.Text + "', '" + UserName.Text + "', '" + Password.Text + "')";
            SqlCommand com = new SqlCommand(sqlQuery, con);

            if (radioGroup.SelectedValue == "Male")
            {
                gender = "Male";
            }
            else
            {
                gender = "Female";
            }

            com.Parameters.AddWithValue("@idnew", newG.ToString());
            com.Parameters.AddWithValue("@fname", FirstName.Text);
            com.Parameters.AddWithValue("@sname", Surname.Text);
            com.Parameters.AddWithValue("@id", ID.Text);
            com.Parameters.AddWithValue("@gend", gender);
            com.Parameters.AddWithValue("@agee", Age.Text);
            com.Parameters.AddWithValue("@races", Race.Text);
            com.Parameters.AddWithValue("@uname", UserName.Text);
            com.Parameters.AddWithValue("@pass", Password.Text);

            com.ExecuteNonQuery();
            con.Close();
            Response.Redirect("Login.aspx");
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);
        }
       

        //int i = 0;
        //if (Password.Text == ConfirmPassword.Text) {
        //    con.Open();
        //    cmd.Connection = con;
        //    cmd.CommandText = "INSERT INTO USER VALUES('" + FirstName.Text + "', '" + Surname.Text + "', '" + ID.Text + "', '" + Gender.Text + "', '" + Age.Text + "', '" + Race.Text + "', '" + UserName.Text + "', '" + Password.Text + "')";
        //    i = cmd.ExecuteNonQuery();
           
        //    if (i > 0) {
        //        Response.Write("Register Successful");
        //        FirstName.Text = "";
        //        Surname.Text = "";
        //        ID.Text = ""; 
        //        UserName.Text = "";
        //        Password.Text = "";
        //        Response.Redirect("Login.aspx");
        //    }
        //    con.Close();
        //} else {
        //    Response.Write("Password does not match");
        //}
    }
}