﻿using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using System;
using System.Web;
using System.Web.UI;
using WebSite1;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.IO;
using System.Xml;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Collections;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Web.SessionState;

public partial class Account_Login : Page
{
    Dictionary<String, ArrayList> map = new Dictionary<string, ArrayList>();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    bool error = false;

    protected void LogIn(object sender, EventArgs e)
    {
        
        //UserNameLogin.CausesValidation = true;
        //CustomValidatorUser.IsValid = true;
    }

    protected void CustomValidatorUser_ServerValidate(object source, ServerValidateEventArgs args)
    {
        userLogin();
        policemanLogin();
        if (!error)
            args.IsValid = false;
    }

    protected void CustomValidatorPass_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (error == true)
            args.IsValid = false;
    }

    class Policeman
    {
        String username { get; set; }
        String password { get; set; }
        String id { get; set; }
    }

    private void policemanLogin()
    {
        con.Open();
        String checkPopo = "select count(*) from [POLICEMAN] where USER_NAME = '" + UserNameLogin.Text + "'";
        SqlCommand comPopo = new SqlCommand(checkPopo, con);
        int userPopo = Convert.ToInt32(comPopo.ExecuteScalar().ToString());
        con.Close();
        if (userPopo > 0)
        {
            
            List<String> list = new List<string>();
            List<String> idz = new List<string>();
            String ID = "";
            String mySQL = "select POLICE_ID, PASSWORD from POLICEMAN where USER_NAME = '" + UserNameLogin.Text + "'";
            SqlCommand myCom = new SqlCommand(mySQL, con);
                try {
                    con.Open();
                    SqlDataReader reader = myCom.ExecuteReader();
                    while (reader.Read())
                    {
                        if (reader["PASSWORD"].ToString().Replace(" ", "") == PasswordLogin.Text)
                        {
                            Session["New"] = UserNameLogin.Text;
                            Session["Policeman"] = UserNameLogin.Text;
                            Session["popoPass"] = PasswordLogin.Text;
                            Response.Write("Password is correct");
                            Session["Date"] = DateTime.Now;
                            ID = reader["POLICE_ID"].ToString().Replace(" ", "");
                            Session["PopoID"] = reader["POLICE_ID"].ToString().Replace(" ", "");
                            Session["userID"] = null;

                            String date = Convert.ToDateTime(Session["Date"].ToString()).Date.ToShortDateString();
                            String time = Convert.ToDateTime(Session["Date"].ToString()).TimeOfDay.Duration().ToString();
                            Response.Write(date + "<br />");
                            Response.Write(time + "<br />");

                            Guid newOne = Guid.NewGuid();
                            String sqlQuery = "insert into [LOG_FILE] (LOG_NUM, DATE, TIME, POLICE_ID) values (@idnew, @dateNow, @timeNow, @userid)";
                            SqlCommand comTime = new SqlCommand(sqlQuery, con);

                            comTime.Parameters.AddWithValue("@idnew", newOne.ToString());
                            comTime.Parameters.AddWithValue("@dateNow", date);
                            comTime.Parameters.AddWithValue("@timeNow", time);
                            comTime.Parameters.AddWithValue("@userid", ID); //idOne
                            //com.Parameters.AddWithValue("@gend", Gender.Text);

                            comTime.ExecuteNonQuery();

                            //con.Close();

                            //Response.Redirect("~/Policeman/PopoMain.aspx");
                        }
                    }
                } catch (Exception e) {
                    Response.Write(e.Message);
                } finally {
                    con.Close();
                    if (Session["Policeman"] != null)
                        Response.Redirect("~/Policeman/PopoMain.aspx");
                }
            //con.Open();
            //for (int i = 0; i < userPopo; i++)
            //{
            //    String checkPassword = "select PASSWORD from [POLICEMAN] where USER_NAME = '" + UserNameLogin.Text + "'";
            //    String id = "select POLICE_ID from POLICEMAN where USER_NAME = '" + UserNameLogin.Text + "'";
                
            //    SqlCommand passCom = new SqlCommand(checkPassword, con);
            //    String password = passCom.ExecuteScalar().ToString().Replace(" ", "");
            //    SqlCommand idCom = new SqlCommand(id, con);
            //    String idOne = idCom.ExecuteScalar().ToString().Replace(" ", "");

                

            //    //String sql = "select POLICE_ID, PASSWORD from POLICEMAN where USER_NAME = '" + UserNameLogin.Text + "'";

            //    //using (con)
            //    //{
            //    //    SqlCommand command = new SqlCommand(
            //    //      sql,
            //    //      con);
            //    //    //con.Open();

            //    //    SqlDataReader reader = command.ExecuteReader();
            //    //    //Response.Write(reader.GetValue(0));
            //    //    //Response.Write(" awe ");
            //    //    //Response.Write(reader.GetValue(1));
            //    //    if (reader.HasRows)
            //    //    {
            //    //        while (reader.Read())
            //    //        {
            //    //            Console.WriteLine("{0}\t{1}", reader.GetString(0),
            //    //                reader.GetString(1));
            //    //        }
            //    //    }
            //    //    else
            //    //    {
            //    //        Console.WriteLine("No rows found.");
            //    //    }
            //    //    reader.Close();
            //    //}

            //    list.Add(password);
            //    idz.Add(idOne);
            //}
            //for (int i = 0; i < list.Count; i++)
            //{
            //    String s = list[i];
            //    if (s == PasswordLogin.Text)
            //    {
            //        Session["New"] = UserNameLogin.Text;
            //        Session["Policeman"] = UserNameLogin.Text;
            //        Session["popoPass"] = PasswordLogin.Text;
            //        Response.Write("Password is correct");
            //        Session["Date"] = DateTime.Now;

                   

            //        String date = Convert.ToDateTime(Session["Date"].ToString()).Date.ToShortDateString();
            //        String time = Convert.ToDateTime(Session["Date"].ToString()).TimeOfDay.Duration().ToString();
            //        Response.Write(date + "<br />");
            //        Response.Write(time + "<br />");

            //        Guid newOne = Guid.NewGuid();
            //        String sqlQuery = "insert into [LOG_FILE] (LOG_NUM, DATE, TIME, POLICE_ID) values (@idnew, @dateNow, @timeNow, @userid)";
            //        SqlCommand comTime = new SqlCommand(sqlQuery, con);

            //        comTime.Parameters.AddWithValue("@idnew", newOne.ToString());
            //        comTime.Parameters.AddWithValue("@dateNow", date);
            //        comTime.Parameters.AddWithValue("@timeNow", time);
            //        comTime.Parameters.AddWithValue("@userid", idz[i]); //idOne
            //        //com.Parameters.AddWithValue("@gend", Gender.Text);

            //        comTime.ExecuteNonQuery();

            //        con.Close();

            //        Response.Redirect("~/Policeman/PopoMain.aspx");
            //    }
                
            //}
            //con.Close();
            if (Session["Policeman"] == null)
            {
                error = true;

            }
        }
        //con.Close();
    }

    private void userLogin()
    {
        con.Open();
        String checkUser = "select count(*) from [USER] where USER_NAME = '" + UserNameLogin.Text + "'";
        SqlCommand com = new SqlCommand(checkUser, con);
        int user = Convert.ToInt32(com.ExecuteScalar().ToString());
        con.Close();
        if (user > 0)
        {

            String ID = "";
            String mySQL = "select PASSWORD, USER_ID from [USER] where USER_NAME = '" + UserNameLogin.Text + "'";
            SqlCommand myCom = new SqlCommand(mySQL, con);
            try
            {
                con.Open();
                    SqlDataReader reader = myCom.ExecuteReader();
                    while (reader.Read())
                    {
                        if (reader["PASSWORD"].ToString().Replace(" ", "") == PasswordLogin.Text)
                        {
                            Session["New"] = UserNameLogin.Text;
                            Session["User"] = UserNameLogin.Text;
                            Session["userPass"] = PasswordLogin.Text;
                            Response.Write("Password is correct");
                            Session["Date"] = DateTime.Now;
                            ID = reader["USER_ID"].ToString().Replace(" ", "");
                            Session["userID"] = reader["USER_ID"].ToString().Replace(" ", "");

                            String date = Convert.ToDateTime(Session["Date"].ToString()).Date.ToShortDateString();
                            String time = Convert.ToDateTime(Session["Date"].ToString()).TimeOfDay.Duration().ToString();
                            Response.Write(date + "<br />");
                            Response.Write(time + "<br />");

                            Guid newOne = Guid.NewGuid();
                            String sqlQuery = "insert into [LOG_FILE] (LOG_NUM, DATE, TIME, USER_ID) values (@idnew, @dateNow, @timeNow, @userid)";
                            SqlCommand comTime = new SqlCommand(sqlQuery, con);

                            comTime.Parameters.AddWithValue("@idnew", newOne.ToString());
                            comTime.Parameters.AddWithValue("@dateNow", date);
                            comTime.Parameters.AddWithValue("@timeNow", time);
                            comTime.Parameters.AddWithValue("@userid", ID);
                            //com.Parameters.AddWithValue("@gend", Gender.Text);

                            comTime.ExecuteNonQuery();

                            
                        }
                    }
            } 
             catch (Exception e) {
                    Response.Write(e.Message);
                } finally {
                    con.Close();

                    if (Session["User"] != null)
                    {
                        if (Session["User"].ToString().Equals("Admin"))
                            Response.Redirect("~/Admin/ViewLogFile.aspx");
                        Response.Redirect("~/User/UserMain.aspx");
                    }
                }
            if (Session["User"] == null)
            {
                error = true;

            }           
        }
    }

    protected void Page_Init(Object sender, EventArgs e)
    {
        Session["New"] = null;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)
        {
            List<String> list = getOnlineUsers();
            for (int i = 0; i < list.Count; i++)
            {
                list[i] = null;
            }
        }
        //RegisterHyperLink.NavigateUrl = "Register";
        //OpenAuthLogin.ReturnUrl = Request.QueryString["ReturnUrl"];
        //var returnUrl = HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
        //if (!String.IsNullOrEmpty(returnUrl))
        //{
        //    RegisterHyperLink.NavigateUrl += "?ReturnUrl=" + returnUrl;
        //}
        //UserNameLogin.Text = GetCountryByIP();
    }

    private List<String> getOnlineUsers()
    {
        List<String> activeSessions = new List<String>();
        object obj = typeof(HttpRuntime).GetProperty("CacheInternal", BindingFlags.NonPublic | BindingFlags.Static).GetValue(null, null);
        object[] obj2 = (object[])obj.GetType().GetField("_caches", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(obj);
        for (int i = 0; i < obj2.Length; i++)
        {
            Hashtable c2 = (Hashtable)obj2[i].GetType().GetField("_entries", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(obj2[i]);
            foreach (DictionaryEntry entry in c2)
            {
                object o1 = entry.Value.GetType().GetProperty("Value", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(entry.Value, null);
                if (o1.GetType().ToString() == "System.Web.SessionState.InProcSessionState")
                {
                    SessionStateItemCollection sess = (SessionStateItemCollection)o1.GetType().GetField("_sessionItems", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(o1);
                    if (sess != null)
                    {
                        if (sess["loggedInUserId"] != null)
                        {
                            activeSessions.Add(sess["loggedInUserId"].ToString());
                        }
                    }
                }
            }
        }
        return activeSessions;
    }

    //public string GetCountryByIP(string ipAddress)
    //{
    //    string ipResponse = IPRequestHelper("http://ipinfodb.com/ip_query_country.php?ip=", ipAddress);

    //    XmlDocument ipInfoXML = new XmlDocument();
    //    ipInfoXML.LoadXml(ipResponse);
    //    XmlNodeList responseXML = ipInfoXML.GetElementsByTagName("Response");

    //    NameValueCollection dataXML = new NameValueCollection();

    //    dataXML.Add(responseXML.Item(0).ChildNodes(2).InnerText, responseXML.Item(0).ChildNodes(2).Value);

    //    string xmlValue = dataXML.Keys(0);

    //    return xmlValue;
    //}

    //public string IPRequestHelper(string url, string ipAddress)
    //{
    //    string checkURL = url + ipAddress;

    //    HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);
    //    HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();

    //    StreamReader responseStream = new StreamReader(objResponse.GetResponseStream());
    //    string responseRead = responseStream.ReadToEnd();

    //    responseStream.Close();
    //    responseStream.Dispose();

    //    return responseRead;
    //}

        //protected void LogIn(object sender, EventArgs e)
        //{
        //    if (IsValid)
        //    {
        //        // Validate the user password
        //        var manager = new UserManager();
        //        ApplicationUser user = manager.Find(UserName.Text, Password.Text);
        //        if (user != null)
        //        {
        //            IdentityHelper.SignIn(manager, user, RememberMe.Checked);
        //            IdentityHelper.RedirectToReturnUrl(Request.QueryString["ReturnUrl"], Response);
        //        }
        //        else
        //        {
        //            FailureText.Text = "Invalid username or password.";
        //            ErrorMessage.Visible = true;
        //        }
        //    }
        //}
   
}