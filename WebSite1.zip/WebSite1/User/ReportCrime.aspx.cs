﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;
using System.Xml;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Collections;

public partial class Crime_ReportCrime : System.Web.UI.Page
{
    Dictionary<String, ArrayList> map = new Dictionary<string, ArrayList>();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);

    string nameSurname;
    string CrNum = "CR1";
    string tm;
    string UI;
    string CI;
    string dateNow;
    string timeNow;
    protected void Page_Load(object sender, EventArgs e)
    {

        addItems();
        con.Open();

        Session["Date"] = DateTime.Now;

        dateNow= Convert.ToDateTime(Session["Date"].ToString()).Date.ToShortDateString();
        tm = Convert.ToDateTime(Session["Date"].ToString()).TimeOfDay.Duration().ToString();


        string uID = "select USER_ID from [USER] where USER_NAME = '" + Session["New"].ToString() + "'";
        String fname = "select FIRST_NAME from [USER] where USER_NAME = '" + Session["New"].ToString() + "'";
        String sname = "select SURNAME from [USER] where USER_NAME = '" + Session["New"].ToString() + "'";

        SqlCommand com1 = new SqlCommand(fname, con);
        SqlCommand com2 = new SqlCommand(sname, con);
        SqlCommand com3 = new SqlCommand(uID, con);

        String realfname = com1.ExecuteScalar().ToString().Replace(" ", "");
        String realsname = com2.ExecuteScalar().ToString().Replace(" ", "");
        String realUi = com3.ExecuteScalar().ToString().Replace(" ", "");
        UI = realUi;
        nameSurname = realfname + " " + realsname;

        name.Text = nameSurname;

        con.Close();
    }

    private void addItems()
    {
        //Motherwell
        ArrayList list = new ArrayList();
        list.Add("Motherwell");
        list.Add("Ikamvelihle");
        map.Add("South African Police Service - Motherwell", list);

        //Swartkops
        list.Clear();
        list.Add("Amsterdamhoek");
        map.Add("South African Police Service - Swartkops", list);

        //New Brighton
        list.Clear();
        list.Add("New Brighton");
        map.Add("South African Police Service - New Brighton", list);

        //Algoa Park
        list.Clear();
        list.Add("Algoa Park");
        map.Add("South African Police Service - Algoa Park", list);

        //Gelvandale
        list.Clear();
        list.Add("Gelvandale");
        map.Add("South African Police Service - Gelvandale", list);

        //Kabega Park
        list.Clear();
        list.Add("Rowallan Park");
        list.Add("Van Der Stel");
        list.Add("Kabega");
        map.Add("South African Police Service - Kabega Park", list);

        //Mount Road
        list.Clear();
        list.Add("Greenacres");
        list.Add("Schauderville");
        list.Add("Steytler");
        map.Add("South African Police Service - Mount Road", list);

        //Walmer
        list.Clear();
        list.Add("Walmer");
        list.Add("Mangold Park");
        list.Add("Walmer Downs");
        map.Add("South African Police Service - Walmer", list);

        //Humewood
        list.Clear();
        list.Add("Humewood");
        list.Add("Summerstrand");
        map.Add("South African Police Service - Humewood", list);
    }

    private String getStation(String suburb)
    {
        String station = "SAPS";
        foreach (KeyValuePair<String, ArrayList> entry in map)
        {
            ArrayList list = entry.Value;
            foreach (String s in list)
            {
                if (s.Equals(suburb))
                    station = entry.Key;
            }
        }
        return station;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        String myCount = "select count(*) from [CRIME]";
        SqlCommand com1 = new SqlCommand(myCount, con);
        int user = 0;
        user = Convert.ToInt32(com1.ExecuteScalar().ToString());

        if (user > 0)
        {

            CrNum = "CR" + (user + 1);
        }
        con.Close();

        String suburb = sub.Text;

        String vict = " ";
        try
        {
            Response.Write(CrNum);
            con.Open();
            String sqlQuery = "insert into [CRIME] (CRIME_ID,VICTIM_CATEGORY, TIME_REPOTED, DATE_REPOTED, DESCRIPTION, LOCATION_ID, USER_ID) values (@idnew,@VIC, @tmReport, @date, @descrip, @loc_id, @U_id)";
            //String sql = "INSERT INTO [USER] VALUES('" + FirstName.Text + "', '" + Surname.Text + "', '" + ID.Text + "', '" + Gender.Text + "', '" + Age.Text + "', '" + Race.Text + "', '" + UserName.Text + "', '" + Password.Text + "')";
            SqlCommand com = new SqlCommand(sqlQuery, con);

            if (radioGroup.SelectedValue == "Victim")
            {
                vict = "Victim";
            }
            else
            {
                vict = "Witness";
            }

            com.Parameters.AddWithValue("@idnew", CrNum);
            com.Parameters.AddWithValue("@VIC", vict);
            com.Parameters.AddWithValue("@tmReport", tm);
            com.Parameters.AddWithValue("@date", dateNow);
            com.Parameters.AddWithValue("@descrip", descrip.Text);
            com.Parameters.AddWithValue("@loc_id","L1" );
            com.Parameters.AddWithValue("@U_id", UI);

            com.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);
        }
    }
}