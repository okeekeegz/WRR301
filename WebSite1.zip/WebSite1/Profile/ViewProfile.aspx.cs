﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Profile_View_Profile : System.Web.UI.Page
{
   bool userBool = false;
   String userID = "", myfname = "", mysname = "", myrank = "";

   void Page_PreInit(Object sender, EventArgs e)
   {
       if (Session["userID"] == null)
           this.MasterPageFile = "~/popo.master";
       else
           this.MasterPageFile = "~/Site.Master";
   }

    protected void Page_Load(object sender, EventArgs e)
    {
        myTable.Rows.Clear();
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        if (Session["userID"] != null)
            userBool = true;
        //User
        if (userBool)
        {
            con.Open();
            String checkUser = "select count(*) from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
            SqlCommand com = new SqlCommand(checkUser, con);
            int user = Convert.ToInt32(com.ExecuteScalar().ToString());
            con.Close();
            if (user == 1) //User
            {
                userBool = true;
                TableHeaderRow h1 = new TableHeaderRow();
                TableHeaderCell c1 = new TableHeaderCell();
                TableHeaderCell c2 = new TableHeaderCell();
                TableHeaderCell c3 = new TableHeaderCell();
                TableHeaderCell c4 = new TableHeaderCell();
                TableHeaderCell c5 = new TableHeaderCell();
                TableHeaderCell c6 = new TableHeaderCell();
                TableHeaderCell c7 = new TableHeaderCell();
                c1.Text = "Username";
                c2.Text = "First name";
                c3.Text = "Surname";
                c4.Text = "ID number";
                c5.Text = "Gender";
                c6.Text = "Age";
                c7.Text = "Race";
                h1.Cells.Add(c1);
                h1.Cells.Add(c2);
                h1.Cells.Add(c3);
                h1.Cells.Add(c4);
                h1.Cells.Add(c5);
                h1.Cells.Add(c6);
                h1.Cells.Add(c7);
                myTable.Rows.Add(h1);

                con.Open();
                String fname = "select FIRST_NAME from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
                String sname = "select SURNAME from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
                String idno = "select ID_NO from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
                String gender = "select GENDER from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
                String age = "select AGE from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
                String race = "select RACE from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";

                SqlCommand com1 = new SqlCommand(fname, con);
                SqlCommand com2 = new SqlCommand(sname, con);
                SqlCommand com3 = new SqlCommand(idno, con);
                SqlCommand com4 = new SqlCommand(gender, con);
                SqlCommand com5 = new SqlCommand(age, con);
                SqlCommand com6 = new SqlCommand(race, con);


                String realfname = com1.ExecuteScalar().ToString().Replace(" ", "");
                String realsname = com2.ExecuteScalar().ToString().Replace(" ", "");
                String realidno = com3.ExecuteScalar().ToString().Replace(" ", "");
                String realgender = com4.ExecuteScalar().ToString().Replace(" ", "");
                String realage = com5.ExecuteScalar().ToString().Replace(" ", "");
                String realrace = com6.ExecuteScalar().ToString().Replace(" ", "");


                TableRow row = new TableRow();
                TableCell cell1 = new TableCell();
                TableCell cell2 = new TableCell();
                TableCell cell3 = new TableCell();
                TableCell cell4 = new TableCell();
                TableCell cell5 = new TableCell();
                TableCell cell6 = new TableCell();
                TableCell cell7 = new TableCell();
                cell1.Text = Session["New"].ToString();
                cell2.Text = realfname;
                cell3.Text = realsname;
                cell4.Text = realidno;
                cell5.Text = realgender;
                cell6.Text = realage;
                cell7.Text = realrace;
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                row.Cells.Add(cell4);
                row.Cells.Add(cell5);
                row.Cells.Add(cell6);
                row.Cells.Add(cell7);
                myTable.Rows.Add(row);

                con.Close();


                //Response.Redirect("~/Default.aspx");

            }
        }
        if (!userBool) { 
        //Policeman
        con.Open();
        String checkPopo = "select count(*) from [POLICEMAN] where POLICE_ID = '" + Session["PopoID"].ToString() + "'";
        SqlCommand comPopo = new SqlCommand(checkPopo, con);
        int userPopo = Convert.ToInt32(comPopo.ExecuteScalar().ToString());
        con.Close();
        if (userPopo == 1) //Policeman
        {
            userBool = false;
            TableHeaderRow h1 = new TableHeaderRow();
            TableHeaderCell c1 = new TableHeaderCell();
            TableHeaderCell c2 = new TableHeaderCell();
            TableHeaderCell c3 = new TableHeaderCell();
            TableHeaderCell c4 = new TableHeaderCell();
            c1.Text = "Username";
            c2.Text = "First name";
            c3.Text = "Surname";
            c4.Text = "Rank";
            h1.Cells.Add(c1);
            h1.Cells.Add(c2);
            h1.Cells.Add(c3);
            h1.Cells.Add(c4);
            myTable.Rows.Add(h1);


            con.Open();
            String fname = "select FIRST_NAME from [POLICEMAN] where POLICE_ID = '" + Session["PopoID"].ToString() + "'";
            String sname = "select SURNAME from [POLICEMAN] where POLICE_ID = '" + Session["PopoID"].ToString() + "'";
            String rank = "select RANK from [POLICEMAN] where POLICE_ID = '" + Session["PopoID"].ToString() + "'";
            String myID = "select POLICE_ID from [POLICEMAN] where POLICE_ID = '" + Session["PopoID"].ToString() + "'";

            SqlCommand com1 = new SqlCommand(fname, con);
            SqlCommand com2 = new SqlCommand(sname, con);
            SqlCommand com3 = new SqlCommand(rank, con);
            SqlCommand com4 = new SqlCommand(myID, con);


            String realfname = com1.ExecuteScalar().ToString().Replace(" ", "");
            String realsname = com2.ExecuteScalar().ToString().Replace(" ", "");
            String realrank = com3.ExecuteScalar().ToString();
            String realID = com4.ExecuteScalar().ToString().Replace(" ", "");

            userID = realID;
            myfname = realfname;
            myrank = realrank;
            mysname = realsname;

            TableRow row = new TableRow();
            TableCell cell1 = new TableCell();
            TableCell cell2 = new TableCell();
            TableCell cell3 = new TableCell();
            TableCell cell4 = new TableCell();
            cell1.Text = Session["New"].ToString();
            cell2.Text = realfname;
            cell3.Text = realsname;
            cell4.Text = realrank;
            row.Cells.Add(cell1);
            row.Cells.Add(cell2);
            row.Cells.Add(cell3);
            row.Cells.Add(cell4);
            myTable.Rows.Add(row);

                con.Close();


                //Response.Redirect("~/Default.aspx");
        }
    }
        }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        Response.Redirect("EditProfile.aspx");
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        if (userBool) //user
        {
            
        } 
        else //policeman
        {
            String sqlQuery = "update [POLICEMAN] set FIRST_NAME = @fname, SURNAME = @sname, RANK = @myrank, USER_NAME = @uname where (POLICE_ID = @userID)";
            SqlCommand comTime = new SqlCommand(sqlQuery, con);
            comTime.Parameters.AddWithValue("@fname", myfname);
            comTime.Parameters.AddWithValue("@sname", mysname);
            comTime.Parameters.AddWithValue("@myrank", myrank);
            comTime.Parameters.AddWithValue("@uname", "rtdsdfxgtrtyrsgfy");
            comTime.Parameters.AddWithValue("@userID", userID);
            Response.Write("Should be working......");
            Response.Write(userID);
        }
    }
}