﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Profile_EditProfile : System.Web.UI.Page
{
    TextBox realfnameBox = new TextBox();
    TextBox realsnameBox = new TextBox();
    TextBox realidnoBox = new TextBox();
    TextBox realgenderBox = new TextBox();
    TextBox realageBox = new TextBox();
    TextBox realraceBox = new TextBox();
    TextBox realfusernameBox = new TextBox();
    TextBox realpassBox = new TextBox();

    ListItem imale = new ListItem("  Male");
    ListItem ifemale = new ListItem("  Female");

    String theUserID = "";
    string polID = "";

    /*police below*/

    TextBox P_realfnameBox = new TextBox();
    TextBox P_realsnameBox = new TextBox();
    //TextBox P_realrankBox = new TextBox();
    
    DropDownList P_realrankBox = new DropDownList();
    TextBox P_realfusernameBox = new TextBox();
    TextBox P_realPassword = new TextBox();

    bool userBool = false;

    void Page_PreInit(Object sender, EventArgs e)
    {
        if (Session["userID"] == null)
            this.MasterPageFile = "~/popo.master";
        else
            this.MasterPageFile = "~/Site.Master";
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        myTableEdit.Rows.Clear();
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        if (Session["userID"] != null)
            userBool = true;
        //User
        if (userBool)
        {
            con.Open();
            String checkUser = "select count(*) from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
            SqlCommand com = new SqlCommand(checkUser, con);
            int user = Convert.ToInt32(com.ExecuteScalar().ToString());
            con.Close();
            if (user == 1) //User
            {
                userBool = true;
                TableHeaderRow h1 = new TableHeaderRow();
                TableHeaderCell c1 = new TableHeaderCell();
                TableHeaderCell c2 = new TableHeaderCell();
                TableHeaderCell c3 = new TableHeaderCell();
                TableHeaderCell c4 = new TableHeaderCell();
                TableHeaderCell c5 = new TableHeaderCell();
                TableHeaderCell c6 = new TableHeaderCell();
                TableHeaderCell c7 = new TableHeaderCell();
                TableHeaderCell c8 = new TableHeaderCell();
                c1.Text = "Username";
                c2.Text = "First name";
                c3.Text = "Surname";
                c4.Text = "ID number";
                c5.Text = "Gender";
                c6.Text = "Age";
                c7.Text = "Race";
                c8.Text = "Password";
                h1.Cells.Add(c1);
                h1.Cells.Add(c2);
                h1.Cells.Add(c3);
                h1.Cells.Add(c4);
                h1.Cells.Add(c5);
                h1.Cells.Add(c6);
                h1.Cells.Add(c7);
                h1.Cells.Add(c8);
                myTableEdit.Rows.Add(h1);

                con.Open();
                String fname = "select FIRST_NAME from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
                String sname = "select SURNAME from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
                String idno = "select ID_NO from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
                String gender = "select GENDER from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
                String age = "select AGE from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
                String race = "select RACE from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
                String pass = "select PASSWORD from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";
                String userID = "select USER_ID from [USER] where USER_ID = '" + Session["userID"].ToString() + "'";



                SqlCommand com1 = new SqlCommand(fname, con);
                SqlCommand com2 = new SqlCommand(sname, con);
                SqlCommand com3 = new SqlCommand(idno, con);
                SqlCommand com4 = new SqlCommand(gender, con);
                SqlCommand com5 = new SqlCommand(age, con);
                SqlCommand com6 = new SqlCommand(race, con);
                SqlCommand com7 = new SqlCommand(pass, con);
                SqlCommand com8 = new SqlCommand(userID, con);


                String realfname = com1.ExecuteScalar().ToString().Replace(" ", "");
                String realsname = com2.ExecuteScalar().ToString().Replace(" ", "");
                String realidno = com3.ExecuteScalar().ToString().Replace(" ", "");
                String realgender = com4.ExecuteScalar().ToString().Replace(" ", "");
                String realage = com5.ExecuteScalar().ToString().Replace(" ", "");
                String realrace = com6.ExecuteScalar().ToString().Replace(" ", "");
                String realpass = com7.ExecuteScalar().ToString().Replace(" ", "");
                String realuserID = com8.ExecuteScalar().ToString().Replace(" ", "");
                theUserID = realuserID;

                RadioButtonList rblist = new RadioButtonList();

                if (realgender == "Male")
                {
                    imale.Selected = true;
                    ifemale.Selected = false;
                }
                else
                {
                    imale.Selected = false;
                    ifemale.Selected = true;
                }
                rblist.Items.Add(imale);
                rblist.Items.Add(ifemale);

                realfnameBox.Text = realfname;
                realsnameBox.Text = realsname;
                realidnoBox.Text = realidno;
                //realgenderBox.Text = realgender;
                realageBox.Text = realage;
                realraceBox.Text = realrace;
                realfusernameBox.Text = Session["New"].ToString();
                realpassBox.Text = realpass;

                realfnameBox.Width = 100;
                realsnameBox.Width = 100;
                realidnoBox.Width = 100;
                //realgenderBox.Width = 100;
                realageBox.Width = 100;
                realraceBox.Width = 100;
                realfusernameBox.Width = 100;
                realpassBox.Width = 100;

                TableRow row = new TableRow();
                TableCell cell1 = new TableCell();
                TableCell cell2 = new TableCell();
                TableCell cell3 = new TableCell();
                TableCell cell4 = new TableCell();
                TableCell cell5 = new TableCell();
                TableCell cell6 = new TableCell();
                TableCell cell7 = new TableCell();
                TableCell cell8 = new TableCell();
                cell1.Controls.Add(realfusernameBox);
                cell2.Controls.Add(realfnameBox);
                cell3.Controls.Add(realsnameBox);
                cell4.Controls.Add(realidnoBox);
                cell5.Controls.Add(rblist);
                cell6.Controls.Add(realageBox);
                cell7.Controls.Add(realraceBox);
                cell8.Controls.Add(realpassBox);
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                row.Cells.Add(cell4);
                row.Cells.Add(cell5);
                row.Cells.Add(cell6);
                row.Cells.Add(cell7);
                myTableEdit.Rows.Add(row);

                con.Close();


                //Response.Redirect("~/Default.aspx");

            }
        }

        //Policeman
        if (!userBool)
        {
            con.Open();
            String checkPopo = "select count(*) from [POLICEMAN] where POLICE_ID = '" + Session["PopoID"].ToString() + "'";
            SqlCommand comPopo = new SqlCommand(checkPopo, con);
            int userPopo = Convert.ToInt32(comPopo.ExecuteScalar().ToString());
            con.Close();
            if (userPopo == 1) //Policeman
            {
                TableHeaderRow h1 = new TableHeaderRow();
                TableHeaderCell c1 = new TableHeaderCell();
                TableHeaderCell c2 = new TableHeaderCell();
                TableHeaderCell c3 = new TableHeaderCell();
                TableHeaderCell c4 = new TableHeaderCell();
                TableHeaderCell c5 = new TableHeaderCell();
                //<asp:DropDownList runat="server" ID="Rank" CssClass="form-control">
                //                <asp:ListItem>General</asp:ListItem>
                //                <asp:ListItem>Lieutenant General</asp:ListItem>
                //                <asp:ListItem>Major General</asp:ListItem>
                //                <asp:ListItem>Colonel</asp:ListItem>
                //                <asp:ListItem>Lieutenant Colonel</asp:ListItem>
                //                <asp:ListItem>Warrant Officer</asp:ListItem>
                //                <asp:ListItem>Sergeant</asp:ListItem>
                //                <asp:ListItem>Constable</asp:ListItem>
                //            </asp:DropDownList>
                P_realrankBox.Items.Add(new ListItem("General"));
                P_realrankBox.Items.Add(new ListItem("Lieutenant General"));
                P_realrankBox.Items.Add(new ListItem("Major General"));
                P_realrankBox.Items.Add(new ListItem("Colonel"));
                P_realrankBox.Items.Add(new ListItem("Lieutenant Colonel"));
                P_realrankBox.Items.Add(new ListItem("Warrant Officer"));
                P_realrankBox.Items.Add(new ListItem("Sergeant"));
                P_realrankBox.Items.Add(new ListItem("Constable"));

                c4.Text = "Username";
                c1.Text = "First name";
                c2.Text = "Surname";
                c3.Text = "Rank";
                c5.Text = "Password";

                h1.Cells.Add(c1);
                h1.Cells.Add(c2);
                h1.Cells.Add(c3);
                h1.Cells.Add(c4);
                h1.Cells.Add(c5);
                myTableEdit.Rows.Add(h1);


                con.Open();

                String fname = "select FIRST_NAME from [POLICEMAN] where POLICE_ID = '" + Session["PopoID"].ToString() + "'";
                String sname = "select SURNAME from [POLICEMAN] where POLICE_ID = '" + Session["PopoID"].ToString() + "'";
                String rank = "select RANK from [POLICEMAN] where POLICE_ID = '" + Session["PopoID"].ToString() + "'";
                String pass = "select PASSWORD from [POLICEMAN] where POLICE_ID = '" + Session["PopoID"].ToString() + "'";
                String userID = "select POLICE_ID from [POLICEMAN] where POLICE_ID = '" + Session["PopoID"].ToString() + "'";


                SqlCommand com1 = new SqlCommand(fname, con);
                SqlCommand com2 = new SqlCommand(sname, con);
                SqlCommand com3 = new SqlCommand(rank, con);
                SqlCommand com4 = new SqlCommand(userID, con);
                SqlCommand com5 = new SqlCommand(pass, con);




                String realfname = com1.ExecuteScalar().ToString().Replace(" ", "");
                String realsname = com2.ExecuteScalar().ToString().Replace(" ", "");
                String realrank = com3.ExecuteScalar().ToString();
                String realuserId = com4.ExecuteScalar().ToString().Replace(" ", "");
                String realPass = com5.ExecuteScalar().ToString().Replace(" ", "");
                polID = realuserId;



                P_realfnameBox.Text = realfname;
                P_realsnameBox.Text = realsname;
                P_realrankBox.Text = realrank;
                P_realfusernameBox.Text = Session["New"].ToString();
                P_realPassword.Text = realPass;

                P_realfnameBox.Width = 100;
                P_realsnameBox.Width = 100;
                P_realrankBox.Width = 100;
                P_realPassword.Width = 100;
                P_realfusernameBox.Width = 100;


                TableRow row = new TableRow();
                TableCell cell1 = new TableCell();
                TableCell cell2 = new TableCell();
                TableCell cell3 = new TableCell();
                TableCell cell4 = new TableCell();
                TableCell cell5 = new TableCell();

                cell1.Text = realfname;
                cell2.Text = realsname;
                cell3.Text = realrank;
                cell4.Text = Session["New"].ToString();
                cell5.Text = realPass;

                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                row.Cells.Add(cell4);
                row.Cells.Add(cell5);
                myTableEdit.Rows.Add(row);

                cell1.Controls.Add(P_realfnameBox);
                cell2.Controls.Add(P_realsnameBox);
                cell3.Controls.Add(P_realrankBox);
                cell4.Controls.Add(P_realfusernameBox);
                cell5.Controls.Add(P_realPassword);

                con.Close();

                //Response.Redirect("~/ViewProfile.aspx");
            }
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (userBool)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            String sqlQuery = "update [USER] set FIRST_NAME = @fname, SURNAME = @sname, ID_NO = @id, GENDER = @gend, AGE = @agee, RACE = @races, USER_NAME = @uname, PASSWORD = @pass where (USER_ID = @userID)";
            SqlCommand comTime = new SqlCommand(sqlQuery, con);

            comTime.Parameters.AddWithValue("@fname", realfnameBox.Text);
            comTime.Parameters.AddWithValue("@sname", realsnameBox.Text);
            comTime.Parameters.AddWithValue("@id", realidnoBox.Text);
            if (imale.Selected)
            {
                comTime.Parameters.AddWithValue("@gend", "Male");
            }
            else
            {
                comTime.Parameters.AddWithValue("@gend", "Female");
            }
            comTime.Parameters.AddWithValue("@agee", realageBox.Text);
            comTime.Parameters.AddWithValue("@races", realraceBox.Text);
            comTime.Parameters.AddWithValue("@uname", realfusernameBox.Text);
            comTime.Parameters.AddWithValue("@pass", realpassBox.Text);
            comTime.Parameters.AddWithValue("@userID", theUserID);

            comTime.ExecuteNonQuery();

            con.Close();
        }
        else
        {

            //Sakhe
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            String sqlQuery = "update [USER] set FIRST_NAME = @fname, SURNAME = @sname, ID_NO = @id, GENDER = @gend, AGE = @agee, RACE = @races, USER_NAME = @uname, PASSWORD = @pass where (USER_ID = @userID)";
            SqlCommand comTime = new SqlCommand(sqlQuery, con);

            comTime.Parameters.AddWithValue("@fname", realfnameBox.Text);
            comTime.Parameters.AddWithValue("@sname", realsnameBox.Text);
            comTime.Parameters.AddWithValue("@id", realidnoBox.Text);
            if (imale.Selected)
            {
                comTime.Parameters.AddWithValue("@gend", "Male");
            }
            else
            {
                comTime.Parameters.AddWithValue("@gend", "Female");
            }
            comTime.Parameters.AddWithValue("@agee", realageBox.Text);
            comTime.Parameters.AddWithValue("@races", realraceBox.Text);
            comTime.Parameters.AddWithValue("@uname", realfusernameBox.Text);
            comTime.Parameters.AddWithValue("@pass", realpassBox.Text);
            comTime.Parameters.AddWithValue("@userID", theUserID);

            comTime.ExecuteNonQuery();

            con.Close();

            // }

            /* if (!userTrue)
             {*/
            con.Open();
            String sqlQ = "update [POLICEMAN] set FIRST_NAME = @fname, SURNAME = @sname, RANK = @RANK,USER_NAME = @uname, PASSWORD = @pass where (POLICE_ID = @policeID)";
            SqlCommand comT = new SqlCommand(sqlQ, con);

            comT.Parameters.AddWithValue("@fname", P_realfnameBox.Text);
            comT.Parameters.AddWithValue("@sname", P_realsnameBox.Text);
            comT.Parameters.AddWithValue("@RANK", P_realrankBox.Text);
            comT.Parameters.AddWithValue("@uname", P_realfusernameBox.Text);
            comT.Parameters.AddWithValue("@pass", P_realPassword.Text);
            comT.Parameters.AddWithValue("@policeID", polID);
            comT.ExecuteNonQuery();
            con.Close();
        }
        Response.Redirect("~/Profile/ViewProfile.aspx");
    }
}